# Neon Dodge PWA

Files:
- index.html
- manifest.json
- sw.js
- icon.svg

To install it, host these files on HTTPS, open index.html in a browser, and use the browser install / add-to-home-screen option.